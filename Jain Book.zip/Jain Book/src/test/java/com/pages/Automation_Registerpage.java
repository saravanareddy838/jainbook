package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Automation_Registerpage {
	static WebDriver driver;
	By login=By.xpath("//*[@id=\"login\"]");
	By newsignup=By.xpath("//*[@id=\"btnsubmit0\"]");
	By email=By.xpath("//*[@id=\"ContentPlaceHolder1_TextBox4\"]");
	By Confrimemail=By.xpath("//*[@id=\"ContentPlaceHolder1_TextBox8\"]");
	By password=By.xpath("//*[@id=\"ContentPlaceHolder1_TextBox6\"]");
	By confirmpass=By.xpath("//*[@id=\"ContentPlaceHolder1_TextBox7\"]");
	By Signup=By.xpath("//*[@id=\"ContentPlaceHolder1_btnsubmit\"]");
public void url1() { // url for launch the chrome
	System.setProperty("webdriver.chrome.driver",  "src\\test\\resources\\driver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
}
public void RegisterPage() throws InterruptedException //using webdriver get visting the testing website
{
	driver.get("https://www.jainbookagency.com/");
	System.out.println(driver.getTitle());
	Thread.sleep(5000);
	 
}
public void RegisterDeatils(String Email,String Remail,String pass,String Rpass) throws InterruptedException
{
	driver.findElement(login).click();
	Thread.sleep(5000);
	driver.findElement(newsignup).click();
	Thread.sleep(5000);
	driver.findElement(email).sendKeys(Email);// passing the vaild mail
	driver.findElement(Confrimemail).sendKeys(Remail); // passing the vaild mail
	driver.findElement(password).sendKeys(pass); // passing the vaild password
	driver.findElement(confirmpass).sendKeys(Rpass); // passing the vaild password
	driver.findElement(Signup).click();
}	
public void Signup() throws InterruptedException
{
	driver.findElement(Signup).click(); // loging button
Thread.sleep(3000);
	driver.close();
}}

