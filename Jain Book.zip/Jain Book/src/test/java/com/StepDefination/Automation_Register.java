package com.StepDefination;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;

import org.junit.runner.RunWith;

import com.pages.Automation_Registerpage;

@RunWith(Cucumber.class)
public class Automation_Register {
	 Automation_Registerpage a=new Automation_Registerpage();
    @Given("^the user launch the chrome application$")
    public void the_user_launch_the_chrome_application() throws Throwable {
     
        a.url1();
    }

    @When("^the user open the jainbookagency Home page$")
    public void the_user_open_the_jainbookagency_home_page() throws Throwable {
       a.RegisterPage();
    }

    @Then("^the user register using (.+) and (.+) and (.+) and (.+)$")
    public void the_user_register_using_and(String Email,String Remail,String pass,String Rpass) throws Throwable {
        a.RegisterDeatils(Email, Remail, pass, Rpass);
    }

    @Then("^click on the register button user nagivate to the next page$")
    public void click_on_the_register_button_user_nagivate_to_the_next_page() throws Throwable {
        a.Signup();
    }

}
